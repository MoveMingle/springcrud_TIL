package org.doit.ik.mapper;

public interface SampleMapper {
	
	String getTime();

}
